package il.ac.hit.beaconfinder.firebase

import java.util.Date

object UserUtils {
    const val UID = "uid"
    const val EMAIL = "email"
    const val USERNAME = "userName"
    const val PHONE_NUMBER = "phoneNumber"
    const val FCM_TOKEN = "fcmToken"
    const val GROUP_INFO = "groupinfo"
    const val CREATED_DATE = "createdDate"
}

