package il.ac.hit.beaconfinder.firebase

data class TagSearchUpdated(val macAddress: String, val notification: String,val uid:String)